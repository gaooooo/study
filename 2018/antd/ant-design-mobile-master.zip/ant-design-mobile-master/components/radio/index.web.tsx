import Radio from './Radio.web';
import RadioItem from './RadioItem.web';

Radio.RadioItem = RadioItem;

export default Radio;
