export {StyleSheet as default} from 'react-native';
