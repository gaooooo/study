import '../../style/';
import '../../flex/style';
import '../../carousel/style';
import './index.less';
