export {Text as default} from 'react-native';
