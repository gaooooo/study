import Flex from './Flex.web';
import FlexItem from './FlexItem.web';

Flex.Item = FlexItem;

export default Flex;
