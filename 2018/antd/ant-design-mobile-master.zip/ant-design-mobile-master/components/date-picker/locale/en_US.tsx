export { default } from 'rmc-date-picker/lib/locale/en_US';
