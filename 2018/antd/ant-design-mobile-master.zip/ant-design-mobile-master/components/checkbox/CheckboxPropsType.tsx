interface CheckboxProps {
  disabled?: boolean;
  checked?: boolean;
  type?: 'normal' | 'agree';
}

export default CheckboxProps;
