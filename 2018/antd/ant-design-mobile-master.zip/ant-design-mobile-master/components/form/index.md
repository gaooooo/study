---
category: Components
type: Components
chinese: 表单集合
english: Form
---


### 定义／Definition
具有数据收集、校验和提交功能的表单，包含选择、输入框、下拉选择框等元素。

### 规则 / Rule
- 表单指意需明确，建议增加引导性的暗文字提醒；
- 同一组列表使用同一种对齐方法；
- 同一组列表不允许多种类型混搭。