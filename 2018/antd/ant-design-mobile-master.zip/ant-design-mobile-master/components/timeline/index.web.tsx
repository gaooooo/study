import Timeline from './Timeline.web';
import TimelineItem from './TimelineItem.web';

Timeline.Item = TimelineItem;
export default Timeline;
