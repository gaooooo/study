import { RefreshControl } from 'react-native';
export default RefreshControl;

// import tsPropsType from './PropsType';
// import splitObject from '../_util/splitObject';
// export default class Drawer extends React.Component<tsPropsType, any> {
//   static propTypes = {
//     children: PropTypes.any,
//   };
//   static defaultProps = {
//   };
//   render() {
//     return (
//       <DrawerLayout
//       >
//         {children}
//       </DrawerLayout>
//     );
//   }
// }
