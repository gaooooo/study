---
order: 3
english: 升级指南
---

此处着重列出升级中的不兼容变化和推荐改动。所有变动请见 [Changelog](/changelog)。

## 0.5.x => 0.6.0

请查看 [Changelog](/changelog#0.6.0)。
