<template>
	<div>
		test template
	</div>
</template>

<script>
import { Group, Cell } from '../components'

export default {
  components: {
    Group,
    Cell
  },
  data () {
    return {
      msg: 'test'
    }
  }
}
</script>