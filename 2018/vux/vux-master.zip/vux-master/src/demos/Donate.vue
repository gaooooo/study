<template>
  <div class="vux-center-h">
    <img src="../assets/demo/wechat_pay.jpg">
  </div>
</template>
