import XSwiper from './xswiper.vue'
import XSwiperItem from './xswiper-item.vue'

export {
	XSwiper,
	XSwiperItem
}
