<template>
	<div class="vux-swiper-slide">
		<slot></slot>
	</div>
</template>
